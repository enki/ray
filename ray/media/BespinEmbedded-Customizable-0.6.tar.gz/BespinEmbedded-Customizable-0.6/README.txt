Bespin Embedded Customizable
============================

The "Customizable" Bespin Embedded release allows you to change which features
are built into your Bespin Embedded script, even including your own custom
features.

You'll need either Python 2.5 with simplejson or Python 2.6 to build your own
custom Bespin.

For more information, look in the docs directory.