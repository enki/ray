Bespin Embedded Drop In
=======================

The "Drop In" Embedded release is one that you can literally just
"drop in" to your site. Include the JavaScript and CSS on your page
and you're all set.

If you need to customize the collection of plugins used by the
embedded editor, you need the Bespin Embedded Customizable
package.

For more information, look in the docs directory.
